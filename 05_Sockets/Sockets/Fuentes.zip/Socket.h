#ifndef _SOCKET_H
#define _SOCKET_H

int Lee_Socket (int fd, char *Datos, int Longitud);
int Escribe_Socket (int fd, char *Datos, int Longitud);


#endif
